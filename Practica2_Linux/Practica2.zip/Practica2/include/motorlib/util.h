#ifndef UTIL_H
#define UTIL_H

#include <cstdlib>

int aleatorio(int tope);

#endif
