#ifndef COMPORTAMIENTOLIB
#define COMPORTAMIENTOLIB

#include "comportamientos/comportamiento.hpp"

#include "../Comportamientos_Jugador/jugador.hpp"
#include "../Comportamientos_Jugador/aldeano.hpp"

#endif
