#include "../Comportamientos_Jugador/jugador.hpp"
#include "motorlib/util.h"

#include <iostream>
#include <cmath>


bool estado::operator == (const estado& status){
	return (fila == status.fila && columna == status.columna);
}

Node::Node(){
		father = nullptr;
		position.fila = 99;
		position.columna = 99;
		objective.fila = 99;
		objective.columna = 99;
		g=h=0;
		movement = actIDLE;
		brujula=0;		
	}

Node::Node(estado start, estado end){
		father=nullptr;
		position.fila = start.fila;
		position.columna = start.columna;
		objective.fila = end.fila;
		objective.columna = end.columna;
		g=h=0;
		movement = actIDLE;
		brujula=0;
}

Node::Node(Node* antecessor, estado start){
		father = antecessor;
		position.fila = start.fila;
		position.columna = start.columna;
		objective.fila = antecessor->objective.fila;
		objective.columna = antecessor->objective.columna;
		g=h=0;
		movement = actIDLE;
		brujula=0;
}

Node::Node(Node* antecessor, Action accion){
		father = antecessor;
		position.fila = antecessor->position.fila;
		position.columna = antecessor->position.columna;
		objective.fila = antecessor->objective.fila;
		objective.columna = antecessor->objective.columna;
		h=0;
		g = father->g+1;
		brujula = antecessor->brujula;
		movement = accion;
		if(accion == actFORWARD){
			if(brujula == 0)
					position.fila = antecessor->position.fila-1;
			if(brujula == 1 )
					position.columna = antecessor->position.columna+1;
			if(brujula == 2 )
					position.fila = antecessor->position.fila+1;
			if(brujula == 3)
					position.columna = antecessor->position.columna-1;
		}
		if(accion == actTURN_R){
			brujula= (brujula+1) % 4;
		}
		if(accion == actTURN_L){
			brujula= ((brujula-1)+4) % 4;
		}
}

double Node::getScore(){
	return g+h;
}

void ComportamientoJugador::PintaPlan(list<Action> plan) {
	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			cout << "A ";
		}
		else if (*it == actTURN_R){
			cout << "D ";
		}
		else if (*it == actTURN_L){
			cout << "I ";
		}
		else {
			cout << "- ";
		}
		it++;
	}
	cout << endl;
}


void AnularMatriz(vector<vector<unsigned char> > &m){
	for (int i=0; i<m[0].size(); i++){
		for (int j=0; j<m.size(); j++){
			m[i][j]=0;
		}
	}
}

void ComportamientoJugador::VisualizaPlan(const estado &st, const list<Action> &plan){
  AnularMatriz(mapaConPlan);
	estado cst = st;

	auto it = plan.begin();
	while (it!=plan.end()){
		if (*it == actFORWARD){
			switch (cst.orientacion) {
				case 0: cst.fila--; break;
				case 1: cst.columna++; break;
				case 2: cst.fila++; break;
				case 3: cst.columna--; break;
			}
			mapaConPlan[cst.fila][cst.columna]=1;
		}
		else if (*it == actTURN_R){
			cst.orientacion = (cst.orientacion+1)%4;
		}
		else {
			cst.orientacion = (cst.orientacion+3)%4;
		}
		it++;
	}
}


bool ComportamientoJugador::pathFinding(const estado &origen, const estado &destino, list<Action> &plan) {
	plan.clear();
 	bool encontrado = false;
	cout <<"\n(pathfinding) coordenadas origen: fila -> " << origen.fila <<" columna -> "<< origen.columna <<endl;
	cout <<"\n(pathfinding) coordenadas destino: fila ->" << destino.fila << "columna ->"<< destino.columna <<endl;
	Astar(plan,encontrado,origen,destino);
	return encontrado;  
}

Action ComportamientoJugador::think(Sensores sensores) {
  Action action = actIDLE;
  estado origen, destino;

	if (sensores.mensajeF != -1){
		fil = sensores.mensajeF;
		col = sensores.mensajeC;
		
		origen.fila = fil;
		origen.columna = col;
		origen.orientacion = brujula;

		destino.fila = sensores.destinoF;
		destino.columna = sensores.destinoC;
	
	}
	
	pathFinding(origen,destino,plan);

	cout << "\n(think)Destino fila: " << sensores.destinoF <<", columna: "<<sensores.destinoC << endl;
	cout << "\n(think)Posicion fila: "<< sensores.mensajeF <<", columna "<<sensores.mensajeC << endl;
	//VisualizaPlan(origen, plan);
	if (!plan.empty()){
		 action = plan.front();
		 plan.erase(plan.begin());
		return action;
	}else
		cout <<"haciendo el tonto";
		return actTURN_R;
	
}

int ComportamientoJugador::interact(Action accion, int valor){
  return false;
}

Action ComportamientoJugador::Avanzar(){
	if (brujula == 0)
		fil= --fil;
	if (brujula == 1)
		col = ++col;
	if (brujula == 2)
		fil = ++fil;
	if (brujula == 3)
		col = --col;
	
	return actFORWARD;
}

Action ComportamientoJugador::Derecha(){
	brujula= (brujula+1) % 4;
	return actTURN_R;
}

Action ComportamientoJugador::Izquierda(){
	brujula= ((brujula-1)+4) % 4;
	return actTURN_L;
}

void ComportamientoJugador::Astar( list<Action> &plan,bool &encontrado, estado ini, estado end){
	Node *root = new Node(ini, end);
	Node *current = nullptr;
	//depuraciones miguelSL
	cout <<"Inicio de Astar"<< endl;
	cout <<"encontrado = " << encontrado << " estado inicial , fila= " << ini.fila << " columna = " <<ini.columna << " \n objetivo: fila= " << end.fila << " columna= " << end.columna << endl;
	
std::set<Node*> abiertos;
	
	std::set<Node*> cerrados;

	abiertos.insert(root);

	while(!abiertos.empty()){
		current = *abiertos.begin();
		for(auto node : abiertos){
			node->h = heuristica(node->position,node->objective);
			if(node->getScore() <= current->getScore())
					current = node;
		}
	
		double totalCost = current->g;
		if(current->position == end){
			encontrado = true;
			break;
		}

		cerrados.insert(current);
		abiertos.erase(abiertos.find(current));
		std::set<Node*> successors;
		expandNode(current, successors);
		
		for(auto node : successors){
			if(abiertos.find(node) != abiertos.end() && cerrados.find(node) != cerrados.end())
					abiertos.insert(successors.begin(), successors.end());
			else if(totalCost < node->g){
						node->father = current;
						node->g = totalCost;
			}
		}
		releaseNodes(successors);

	}
		int i = 0;
		std::list<Action> acciones;
		while(current != nullptr){
		 	++i;
			cout << "\n (Astar)Nodo[" << i << "]  fila: "<<current->position.fila <<" columna: "<< current->position.columna << " movimiento :"<< current->movement << endl ;
			acciones.push_back(current->movement);
			current = current->father;

		}
		//iterar al reves
		for(auto act : acciones){
			plan.push_back(act);
		}

		//liberar punteros
		releaseNodes(abiertos);
		releaseNodes(cerrados);
		
}

void ComportamientoJugador::expandNode(Node* nodo, std::set<Node *> &successors){
		//limpiar succesors
		for(auto node : successors){	
				successors.erase(successors.find(node));
		}	
				Node* son1 = new Node(nodo, actFORWARD);
				successors.insert(son1);
				Node* son2 = new Node(nodo, actTURN_R);
				successors.insert(son2);
				Node* son3 = new Node(nodo, actTURN_L);
				successors.insert(son3);
			
	}

bool ComportamientoJugador::isWalkable(std::vector< std::vector< unsigned char> > mapaR){
	return true;
	}

double ComportamientoJugador::heuristica(estado start, estado end){
		return abs(sqrt(pow(abs(start.fila - end.fila) + abs(start.columna - end.columna),2)));
	}

void ComportamientoJugador::releaseNodes(std::set<Node *> &nodes_)
{
    for (auto it = nodes_.begin(); it != nodes_.end();) {
        delete *it;
        it = nodes_.erase(it);
    }
}

